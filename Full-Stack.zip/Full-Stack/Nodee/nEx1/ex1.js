const nodemailer = require('nodemailer');
 
nodemailer.createTransport({
    service: 'gmail', // Use your email provider (e.g., Gmail)
    auth: {
        user: 'your-email@gmail.com', // Replace with your email
        pass: 'your-email-password'  // Replace with your email password
    }
}).sendMail()