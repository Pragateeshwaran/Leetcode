const https = require('https');

https.get('https://nodejs.org/en/download', (res) => {
    let d = '';
    res.on('data', (c) => {
        d += c;
    });
    res.on('end', () => {
        console.log('Response Data:', JSON.parse(d));
    });
}).on('error', (err) => {
    console.error('Error:', err.message);
});

